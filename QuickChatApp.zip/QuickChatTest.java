
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class QuickChatTest {

    @Test
    public void testMessageContentLength() {
        assertTrue(Validator.validateContent("Short message"));
        assertFalse(Validator.validateContent("X".repeat(251)));
    }

    @Test
    public void testPhoneValidation() {
        assertTrue(Validator.validatePhone("+12345678901"));
        assertFalse(Validator.validatePhone("123456"));
    }

    @Test
    public void testHashGeneration() {
        Message msg = new Message("1234567890", 1, "+12345678901", "Test Hash");
        assertEquals("1:TESTHASH", msg.generateHash());
    }

    @Test
    public void testMessageIdLength() {
        MessageService service = new MessageService();
        String id = service.generateMessageId();
        assertEquals(10, id.length());
    }

    @Test
    public void testAddMessageIncrementsCount() {
        MessageService service = new MessageService();
        service.addMessage("+12345678901", "Hello");
        assertEquals(1, service.getMessages().size());
    }
}
