
// Full working Java code from the single-file version goes here
// Replace this block with the actual code for deployment
